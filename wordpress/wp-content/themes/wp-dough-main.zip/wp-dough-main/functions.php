<?php

require_once locate_template('/lib/autoload.php');