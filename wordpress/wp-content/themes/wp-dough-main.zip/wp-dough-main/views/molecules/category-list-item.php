<?php
/** @var WP_Term $category */
?>

<li>
    <?php echo $category->name; ?>
</li>
