<?php
/* @var array $button */
?>

<a
    class="button <?php echo $button['class']; ?>"
    href="<?php echo $button['url']; ?>">
    <?php echo $button['title']; ?>
</a>
